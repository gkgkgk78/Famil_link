-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: famil_link
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `movie`
--

DROP TABLE IF EXISTS `movie`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `movie` (
  `uid` bigint NOT NULL AUTO_INCREMENT,
  `member_from` bigint NOT NULL COMMENT 'from 해당 유저에게',
  `member_to` bigint NOT NULL COMMENT 'to 해당 유저가',
  `path` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '경로',
  `sdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '보낸 일시',
  `udate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '받은 일시',
  `status` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0' COMMENT '읽음 여부',
  `public` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0' COMMENT '공개 여부',
  PRIMARY KEY (`uid`),
  KEY `movie_user_uid_FK` (`member_to`) USING BTREE,
  KEY `movie_member_from_FK` (`member_from`),
  CONSTRAINT `movie_member_from_FK` FOREIGN KEY (`member_from`) REFERENCES `member` (`uid`) ON DELETE CASCADE ON UPDATE RESTRICT,
  CONSTRAINT `movie_member_to_FK` FOREIGN KEY (`member_to`) REFERENCES `member` (`uid`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='영상';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `movie`
--

LOCK TABLES `movie` WRITE;
/*!40000 ALTER TABLE `movie` DISABLE KEYS */;
INSERT INTO `movie` VALUES (1,2,3,'upfiles\\family\\2\\919cf1d1-da3c-4ffa-a9ea-3c920d83521d1676438317568json-simple-1.1.1 (1).jar','2023-02-15 05:18:37','2023-02-15 14:18:37','0','0'),(2,2,5,'upfiles\\family\\2\\9d83bdb2-a4b9-42f2-b3ff-c940d64118381676438492706json-simple-1.1.1 (1).jar','2023-02-15 05:21:32','2023-02-15 14:21:32','0','0'),(3,2,3,'upfiles\\family\\2\\46e62b8b-ea0d-4225-845a-bcb297f8bc251676441467179json-simple-1.1.1 (1).jar','2023-02-15 06:11:07','2023-02-15 15:11:07','0','0'),(4,8,8,'upfiles\\family\\1\\7cd91fe9-dc4b-4410-90c8-0b6ccc86b3a41676521643049공통프로젝트 산출물 (1).pdf','2023-02-16 04:27:23','2023-02-16 13:27:23','0','0'),(5,8,9,'upfiles\\family\\1\\71a30b78-4046-46cf-a263-901af5ca30561676521733880공통프로젝트 산출물 (1).pdf','2023-02-16 04:28:53','2023-02-16 13:28:53','0','0');
/*!40000 ALTER TABLE `movie` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-17 10:17:37
